defmodule TaksoWeb.BookingView do
  use TaksoWeb, :view
end
