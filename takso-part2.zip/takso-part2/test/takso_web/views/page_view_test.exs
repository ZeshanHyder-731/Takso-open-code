defmodule TaksoWeb.PageViewTest do
  use TaksoWeb.ConnCase, async: true
end
