# Takso (part 2)

Web application in Phoenix

- Part 1: Testing the controllers
- Part 2: Let us go back to BDD
- Part 3: Ecto queries
- Part 4: Testing model validations

### Stack
- Elixir (Phoenix)
- TDD approach 
- BDD tests ([WhiteBread](https://github.com/meadery/white-bread))
