defmodule Takso.Mailer do
  use Swoosh.Mailer, otp_app: :takso
end
