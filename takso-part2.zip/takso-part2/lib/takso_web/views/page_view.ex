defmodule TaksoWeb.PageView do
  use TaksoWeb, :view
end
