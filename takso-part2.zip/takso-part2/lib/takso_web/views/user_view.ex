defmodule TaksoWeb.UserView do
  use TaksoWeb, :view
end
